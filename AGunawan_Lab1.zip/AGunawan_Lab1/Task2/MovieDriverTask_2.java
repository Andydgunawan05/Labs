import java.util.Scanner;

public class MovieDriverTask_2 {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		boolean running = true;
		String title, rating, keepRunning;
		int tickets;
		
		while(running == true){
			Movie m  = new Movie();
			
			System.out.println("Enter the name of a movie:");
			title = input.nextLine();
			m.setTitle(title);
			
			System.out.println("Enter the rating of the movie:");
			rating = input.nextLine();
			m.setRating(rating);
			
			System.out.println("Enter the number of tickets sold for this movie:");
			tickets = input.nextInt();
			m.setSoldTickets(tickets);
			
			System.out.println(m.toString());
			
			input.nextLine();

			
			System.out.println("Do you want to enter another? (y or n)");
			keepRunning = input.nextLine();
			
			if (keepRunning.equalsIgnoreCase("n")) {
				running = false;
			}
			
		}
		
		System.out.println("GoodBye!");
		input.close();
	}

}

